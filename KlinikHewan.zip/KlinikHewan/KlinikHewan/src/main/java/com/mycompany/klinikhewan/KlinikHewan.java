/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.klinikhewan;

/**
 *
 * @author syahrilfarhan
 */
public class KlinikHewan {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
